document.addEventListener("DOMContentLoaded", () => {
  // Слайдер
  new Swiper(".mainSwiper", {
    slidesPerView: "auto",
    spaceBetween: 45,
    loop: true,
    pagination: {
      el: ".swiper-pagination",
      clickable: true,
    },
    navigation: {
      nextEl: ".mainSwiper-btn-next",
      prevEl: ".mainSwiper-btn-prev",
    },
    breakpoints: {
      0: {
        spaceBetween: 15,
      },
      651: {
        spaceBetween: 45,
      },
    },
  });

  // Каталог попап
  var headerBtnCatalog = document.querySelector(".header-btn-catalog"),
    sidebarCatalog = document.querySelector(".sidebar-catalog-menu"),
    el = document.getElementsByClassName(
      "wc-block-product-categories-list-item"
    );
  headerBtnCatalog.addEventListener("click", () => {
    if (sidebarCatalog.classList.contains("open")) {
      headerBtnCatalog.classList.remove("open");
      sidebarCatalog.classList.remove("open");
    } else {
      headerBtnCatalog.classList.add("open");
      sidebarCatalog.classList.add("open");
    }
  });
  for (var i = 0; i < el.length; i++) {
    el[i].addEventListener("mouseenter", showSub, false);
    el[i].addEventListener("mouseleave", hideSub, false);
  }
  function showSub(e) {
    if (this.children.length > 1) {
      console.log(this.parentNode);
      this.parentNode.style.border = "none";
      this.children[0].classList.add("open");
      this.children[1].classList.add("open");
    } else {
      return false;
    }
  }
  function hideSub(e) {
    if (this.children.length > 1) {
      this.children[0].classList.remove("open");
      this.children[1].classList.remove("open");
    } else {
      return false;
    }
  }

  // Характеристики
  var characteristicsBtn = document.querySelector(".characteristics-wrapper a"),
    characteristicsWrapper = document.querySelector(".characteristics-wrapper");
  characteristics = document.querySelector(
    ".characteristics-wrapper .some-class"
  );
  if (characteristics) {
    characteristicsWrapper.classList.add("open");
    characteristicsBtn.addEventListener("click", () => {
      if (characteristicsWrapper.classList.contains("open")) {
        characteristicsWrapper.classList.remove("open");
        gsap.to(characteristics, { height: 0, duration: 0.75 });
      } else {
        characteristicsWrapper.classList.add("open");
        gsap.to(characteristics, { height: "auto", duration: 0.75 });
      }
    });
  }

  // Сортировка и фильтры
  function catalog() {
    var select = document.querySelector(".select");
    var selectWrapper = document.querySelector(".select-wrapper");
    var catalogBtnColumn = document.querySelector(".catalog_block-btn-column");
    var catalogBtnRow = document.querySelector(".catalog_block-btn-row");
    var productsCards = document.querySelector(".products-cards");
    var selectOption = document.querySelectorAll(".select-option");
    var selectBtn = document.querySelector(".select-text");
    if (productsCards) {
      catalogBtnColumn.addEventListener("click", () => {
        productsCards.classList.remove("products-cards-row");
        productsCards.classList.add("products-cards-column");
      });
      catalogBtnRow.addEventListener("click", () => {
        productsCards.classList.remove("products-cards-column");
        productsCards.classList.add("products-cards-row");
      });
    }
    function closeSelect() {
      select.classList.remove("open");
      gsap.to(selectWrapper, { height: 0, y: -20, duration: 0.65 });
    }
    if (selectBtn) {
      selectBtn.addEventListener("click", () => {
        if (select.classList.contains("open")) {
          closeSelect();
        } else {
          select.classList.add("open");
          gsap.to(selectWrapper, { height: "auto", y: 0, duration: 0.65 });
        }
      });
    }
    selectOption.forEach((el) => {
      el.addEventListener("click", (e) => {
        selectBtn.innerHTML = e.target.innerText;
        closeSelect();
      });
    });
  }
  catalog();
  let observer = new MutationObserver(() => {
    catalog();
  });
  observer.observe(document.querySelector(".products-cards"), {
    childList: true, // наблюдать за непосредственными детьми
    subtree: true, // и более глубокими потомками
  });
});
