document.addEventListener("DOMContentLoaded", () => {
  // Слайдер
  new Swiper(".mainSwiper", {
    slidesPerView: "auto",
    spaceBetween: 45,
    loop: true,
    pagination: {
      el: ".swiper-pagination",
      clickable: true,
    },
    navigation: {
      nextEl: ".mainSwiper-btn-next",
      prevEl: ".mainSwiper-btn-prev",
    },
    breakpoints: {
      0: {
        spaceBetween: 15,
      },
      651: {
        spaceBetween: 45,
      },
    },
  });

  // Каталог попап
  var headerBtnCatalog = document.querySelector(".header-btn-catalog"),
    sidebarCatalog = document.querySelector(".sidebar-catalog-menu"),
    el = document.getElementsByClassName(
      "wc-block-product-categories-list-item"
    );
  headerBtnCatalog.addEventListener("click", () => {
    if (sidebarCatalog.classList.contains("open")) {
      headerBtnCatalog.classList.remove("open");
      sidebarCatalog.classList.remove("open");
    } else {
      headerBtnCatalog.classList.add("open");
      sidebarCatalog.classList.add("open");
    }
  });
  for (var i = 0; i < el.length; i++) {
    el[i].addEventListener("mouseenter", showSub, false);
    el[i].addEventListener("mouseleave", hideSub, false);
  }
  function showSub(e) {
    if (this.children.length > 1) {
      console.log(this.parentNode);
      this.parentNode.style.border = "none";
      this.children[0].classList.add("open");
      this.children[1].classList.add("open");
    } else {
      return false;
    }
  }
  function hideSub(e) {
    if (this.children.length > 1) {
      this.children[0].classList.remove("open");
      this.children[1].classList.remove("open");
    } else {
      return false;
    }
  }
  // btn.forEach((element) => {
  //   element.addEventListener("mouseover", (e) => {
  //     // element.nextElementSibling().style.display = "block";
  //     // console.log(e.target.parentNode);
  //     // e.target.parentChild
  //     e.target.parentNode.classList.add("open");
  //     if (element.nextElementSibling) {
  //       // element.nextElementSibling.querySelectorAll("li").forEach.classList.add("open");
  //       // element.nextElementSibling.querySelectorAll("li").forEach((elem) => {
  //       //   elem;
  //       // });
  //     }
  //   });
  //   element.addEventListener("mouseout", (e) => {
  //     e.target.parentNode.classList.remove("open");
  //     // element.nextElementSibling().style.display = "block";
  //     if (element.nextElementSibling) {
  //       // element.nextElementSibling.nextElementSibling.classList.remove("open");
  //     }
  //   });
  // });

  // Характеристики
  var characteristicsBtn = document.querySelector(".characteristics-wrapper a"),
    characteristicsWrapper = document.querySelector(".characteristics-wrapper");
  characteristics = document.querySelector(
    ".characteristics-wrapper .some-class"
  );
  if (characteristics) {
    characteristicsBtn.addEventListener("click", () => {
      if (characteristicsWrapper.classList.contains("open")) {
        characteristicsWrapper.classList.remove("open");
        gsap.to(characteristics, { height: 0, duration: 0.75 });
      } else {
        characteristicsWrapper.classList.add("open");
        gsap.to(characteristics, { height: "auto", duration: 0.75 });
      }
    });
  }

  // Сортировка и фильтры
  var select = document.querySelector(".select");
  var selectOpen = document.querySelector(".select-open");
  var selectWrapper = document.querySelector(".select-wrapper");
  var orderby = document.querySelectorAll(".orderby option");
  // let div = document.createElement("div");
  for (let i = 0; i < orderby.length; i++) {
    const element = orderby[i];
    // console.log(element.innerHTML);
    let div = document.createElement("div");
    div.className = "select-option";
    div.setAttribute("value", element.value);
    div.innerHTML = `${element.innerHTML}`;
    selectOpen.append(div);
    // selectOption.forEach((el) => {
    //   el.addEventListener("click", (e) => {
    //     selectBtn.innerHTML = e.target.innerText;
    //     // element.selected = true;
    //   });
    // });
  }
  var selectOption = document.querySelectorAll(".select-option");
  var selectBtn = document.querySelector(".select-text");
  function closeSelect() {
    select.classList.remove("open");
    gsap.to(selectWrapper, { height: 0, y: -20, duration: 0.65 });
  }
  if (selectBtn) {
    selectBtn.addEventListener("click", () => {
      if (select.classList.contains("open")) {
        closeSelect();
      } else {
        select.classList.add("open");
        gsap.to(selectWrapper, { height: "auto", y: 0, duration: 0.65 });
      }
    });
  }
  // selectOption.addEventListener("click", (e) => {
  //   selectBtn.innerHTML = e.target.innerText;
  // });
  selectOption.forEach((el) => {
    el.addEventListener("click", (e) => {
      selectBtn.innerHTML = e.target.innerText;
      closeSelect();
      // orderby.options[1].selected = true;
    });
  });
});
